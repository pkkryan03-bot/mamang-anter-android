package com.mamangantar.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID

private val Blue = Color(0xFF1264C8)
private val PaleBlue = Color(0xFFEAF3FF)

data class Order(
    val id: String,
    val customer: String,
    val phone: String,
    val service: String,
    val pickup: String,
    val destination: String,
    val note: String,
    val fare: Int,
    val payment: String,
    val status: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MamangApp() }
    }
}

@Composable
fun MamangApp() {
    val context = LocalContext.current
    var orders by remember { mutableStateOf(loadOrders(context)) }
    var tab by remember { mutableStateOf("Beranda") }
    var showForm by remember { mutableStateOf(false) }

    fun refresh() { orders = loadOrders(context) }
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Blue, secondary = Blue, background = Color(0xFFF6F8FC))
    ) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    listOf("Beranda", "Pesanan", "Pendapatan").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Beranda" -> Icons.Default.Home
                                        "Pesanan" -> Icons.Default.ReceiptLong
                                        else -> Icons.Default.AccountBalanceWallet
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            },
            floatingActionButton = {
                if (tab != "Pendapatan" && !showForm) {
                    FloatingActionButton(onClick = { showForm = true }, containerColor = Blue, contentColor = Color.White) {
                        Icon(Icons.Default.Add, contentDescription = "Pesanan baru")
                    }
                }
            }
        ) { padding ->
            if (showForm) {
                OrderForm(
                    modifier = Modifier.padding(padding),
                    onSave = { order ->
                        val updated = loadOrders(context).toMutableList().apply { add(0, order) }
                        saveOrders(context, updated)
                        refresh()
                        showForm = false
                        tab = "Pesanan"
                    },
                    onCancel = { showForm = false }
                )
            } else {
                when (tab) {
                    "Beranda" -> HomeScreen(orders, Modifier.padding(padding), onNew = { showForm = true }, onWhatsApp = { openWhatsApp(context) })
                    "Pesanan" -> OrdersScreen(orders, Modifier.padding(padding), onStatus = { id, status ->
                        val updated = orders.map { if (it.id == id) it.copy(status = status) else it }
                        saveOrders(context, updated); refresh()
                    })
                    else -> IncomeScreen(orders, Modifier.padding(padding))
                }
            }
        }
    }
}

@Composable
fun Header() {
    Surface(color = Blue, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text("MAMANG ANTER", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Layanan lokal Cimaragas dan sekitarnya", color = Color.White.copy(alpha = .9f))
        }
    }
}

@Composable
fun HomeScreen(orders: List<Order>, modifier: Modifier, onNew: () -> Unit, onWhatsApp: () -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header()
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Halo, Driver!", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard("Pesanan", orders.size.toString(), Modifier.weight(1f))
                SummaryCard("Selesai", orders.count { it.status == "Selesai" }.toString(), Modifier.weight(1f))
            }
            Text("Pilih layanan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            listOf(
                "Antar-jemput penumpang" to Icons.Default.TwoWheeler,
                "Antar barang" to Icons.Default.Inventory2,
                "Jasa suruh" to Icons.Default.Assignment,
                "Titip beli" to Icons.Default.ShoppingBasket
            ).forEach { (name, icon) ->
                ElevatedCard(onClick = onNew, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(icon, contentDescription = null, tint = Blue)
                        Spacer(Modifier.width(12.dp))
                        Text(name, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, contentDescription = null)
                    }
                }
            }
            Button(onClick = onNew, modifier = Modifier.fillMaxWidth()) { Text("Catat Pesanan Baru") }
            OutlinedButton(onClick = onWhatsApp, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Chat, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Buka WhatsApp")
            }
            Text("Catatan: pesanan WhatsApp dicatat manual melalui tombol Catat Pesanan Baru.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
    }
}

@Composable
fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Color.Gray)
            Text(value, style = MaterialTheme.typography.headlineMedium, color = Blue, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun OrderForm(modifier: Modifier, onSave: (Order) -> Unit, onCancel: () -> Unit) {
    var customer by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var service by remember { mutableStateOf("Antar-jemput penumpang") }
    var pickup by remember { mutableStateOf("") }
    var destination by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var fare by remember { mutableStateOf("10000") }
    var payment by remember { mutableStateOf("Tunai") }
    var error by remember { mutableStateOf("") }
    val services = listOf("Antar-jemput penumpang", "Antar barang", "Jasa suruh", "Titip beli")

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Pesanan Baru", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(customer, { customer = it }, label = { Text("Nama pelanggan") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it }, label = { Text("Nomor WhatsApp") }, modifier = Modifier.fillMaxWidth())
        Text("Jenis layanan", fontWeight = FontWeight.SemiBold)
        services.forEach { item ->
            FilterChip(selected = service == item, onClick = { service = item }, label = { Text(item) })
        }
        OutlinedTextField(pickup, { pickup = it }, label = { Text("Alamat penjemputan / lokasi awal") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(destination, { destination = it }, label = { Text("Tujuan / lokasi belanja") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(note, { note = it }, label = { Text("Catatan pesanan") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        OutlinedTextField(fare, { fare = it.filter(Char::isDigit) }, label = { Text("Tarif (rupiah)") }, modifier = Modifier.fillMaxWidth())
        Text("Pembayaran", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Tunai", "QRIS", "Transfer").forEach {
                FilterChip(selected = payment == it, onClick = { payment = it }, label = { Text(it) })
            }
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Button(
            onClick = {
                if (customer.isBlank() || phone.isBlank() || pickup.isBlank() || fare.isBlank()) {
                    error = "Lengkapi nama, WhatsApp, lokasi awal, dan tarif."
                } else {
                    onSave(Order(UUID.randomUUID().toString(), customer, phone, service, pickup, destination, note,
                        fare.toIntOrNull() ?: 0, payment, "Menunggu"))
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Simpan Pesanan") }
        OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Batal") }
    }
}

@Composable
fun OrdersScreen(orders: List<Order>, modifier: Modifier, onStatus: (String, String) -> Unit) {
    Column(modifier.fillMaxSize()) {
        Header()
        if (orders.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Belum ada pesanan.") }
        } else {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(orders, key = { it.id }) { order ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(order.service, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                AssistChip(onClick = {}, label = { Text(order.status) })
                            }
                            Text("${order.customer} • ${order.phone}")
                            Text("Awal: ${order.pickup}")
                            if (order.destination.isNotBlank()) Text("Tujuan: ${order.destination}")
                            Text("Tarif: ${rupiah(order.fare)} • ${order.payment}", color = Blue, fontWeight = FontWeight.SemiBold)
                            if (order.note.isNotBlank()) Text("Catatan: ${order.note}", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Diterima", "Dalam perjalanan", "Selesai").forEach { status ->
                                    TextButton(onClick = { onStatus(order.id, status) }) { Text(status, maxLines = 1) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun IncomeScreen(orders: List<Order>, modifier: Modifier) {
    val done = orders.filter { it.status == "Selesai" }
    Column(modifier.fillMaxSize()) {
        Header()
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Ringkasan Pendapatan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            SummaryCard("Total pesanan selesai", done.size.toString(), Modifier.fillMaxWidth())
            SummaryCard("Total pendapatan tercatat", rupiah(done.sumOf { it.fare }), Modifier.fillMaxWidth())
            Text("Angka dihitung dari pesanan berstatus Selesai. Ini catatan manual, bukan laporan rekening bank.")
        }
    }
}

fun rupiah(value: Int): String = NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(value)

fun openWhatsApp(context: Context) {
    // Ganti nomor ini dengan nomor WhatsApp usaha dalam format internasional tanpa tanda +.
    val businessNumber = "6282216996303"
    val message = "Halo MAMANG ANTER, saya ingin memesan layanan."
    val uri = Uri.parse("https://wa.me/$businessNumber?text=${Uri.encode(message)}")
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
    } catch (_: Exception) { }
}

fun saveOrders(context: Context, orders: List<Order>) {
    val array = JSONArray()
    orders.forEach { o ->
        array.put(JSONObject().apply {
            put("id", o.id); put("customer", o.customer); put("phone", o.phone)
            put("service", o.service); put("pickup", o.pickup); put("destination", o.destination)
            put("note", o.note); put("fare", o.fare); put("payment", o.payment); put("status", o.status)
        })
    }
    context.getSharedPreferences("mamang_anter", Context.MODE_PRIVATE).edit().putString("orders", array.toString()).apply()
}

fun loadOrders(context: Context): List<Order> {
    val raw = context.getSharedPreferences("mamang_anter", Context.MODE_PRIVATE).getString("orders", "[]") ?: "[]"
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Order(o.optString("id"), o.optString("customer"), o.optString("phone"), o.optString("service"),
                o.optString("pickup"), o.optString("destination"), o.optString("note"), o.optInt("fare"),
                o.optString("payment"), o.optString("status"))
        }
    } catch (_: Exception) { emptyList() }
}
