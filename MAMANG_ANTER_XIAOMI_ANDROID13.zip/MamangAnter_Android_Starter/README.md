# MAMANG ANTER — Android Starter

Starter project Android (Kotlin + Jetpack Compose) untuk operasional pribadi satu driver.

## Fitur yang tersedia
- Beranda dengan empat layanan.
- Form pencatatan pesanan.
- Penyimpanan lokal di SharedPreferences.
- Daftar pesanan dan perubahan status.
- Rekap pendapatan dari pesanan berstatus Selesai.
- Tombol membuka WhatsApp ke nomor usaha MAMANG ANTER yang sudah dikonfigurasi.

## Batasan versi starter
- Belum ada backend/server, sehingga pesanan dari HP pelanggan tidak otomatis masuk ke HP pengelola.
- Pemesanan aplikasi saat ini adalah pencatatan di perangkat yang menjalankan aplikasi.
- Pesanan WhatsApp perlu dicatat manual.
- Belum ada GPS, peta/rute, notifikasi push, QRIS otomatis, transfer otomatis, akun pelanggan, atau APK siap pasang.
- Data tersimpan lokal; uninstall aplikasi dapat menghapus data. Tambahkan mekanisme backup sebelum dipakai untuk operasional penting.

## Cara membuka
1. Ekstrak ZIP.
2. Buka folder `MamangAnter_Android_Starter` melalui Android Studio.
3. Gunakan JDK 17 dan Android SDK 35.
4. Tunggu Gradle Sync.
5. Nomor WhatsApp bisnis sudah diatur ke `6282216996303` (format internasional tanpa tanda +). Jika nomor berubah, perbarui nilai `businessNumber` di `MainActivity.kt`.
6. Jalankan pada perangkat Android atau emulator.

## Tarif
Tarif dapat dimasukkan manual pada formulir. Aturan otomatis Rp10.000 untuk 1–2 km dan tambahan Rp3.000/km setelah 2 km belum diotomatisasi karena kebijakan pembulatan jarak pecahan belum ditentukan.
